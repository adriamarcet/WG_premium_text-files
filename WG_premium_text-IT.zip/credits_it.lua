local tableText = {
	"Basato su  \"Gardens\" creato da", "Pere Pau Listosella" ,
	"Design aggiuntivo","Sergi Marcet",
	"Capo programmatore","Adrián Ramírez",
	"\n","",
	"Arte e animazione", 
	"Manager progetto", "Adrià Marcet",
	"Effetti sonori","Carlos del Pozo",
	"Tema principale\"Goblin Kingdom\"", "Chris Egan",
	"\n","",
	"Tester",
	"Adrià Marcet",
	"Eva Santos",
	"Lluna Pinado",
	"Pilar Azpiroz",
	"\n"," ",
	"Traduttori",
	"Spagnolo latino americano", "Guillermo Issa Martínez",
	"Tedesco","Lucia Castro",
	"Francese","Jean-Noel Guenot",
	"Portoghese","Marina Forato",
	"Inglese","Jofre Bellés",
	"Italiano","Ester Guerini",
	"Ringraziamenti",
	"La realizzazione di questo gioco non sarebbe stata possibile senza l'aiuto di", "Lorenzo Ramírez, Carmenchi Sánchez,",
	"e tutti gli amici e la famiglia che hanno supportato questo progetto."
	--<< END translate >>--
}
return tableText
--<< Textos del createGame >>--
local tableText = {	
	--blancas 
	--<< START translate >>--
	title1 = "Seleziona il numero di giocatori",
	oneplayer = "1 giocatore",
	twoplayer = "2 giocatori",
	threeplayer = "3 giocatori",
	fourplayer = "4 giocatori",
	clasica = "Modalità Classica",
	duelo   = "Modalità Duello",
	online  = "Modalità Online",
	playerHud = "Giocatori",
	btnPlay = "Gioca",
	player = "Giocatore",
	ia = "Robot",
	easy = "Facile",
	medium = "Media",
	hard = "Difficile",
	--<< END translate >>--
}
return tableText
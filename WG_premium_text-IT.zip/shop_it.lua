--<< Textos de la tienda >>--
local tableText = {
	--blancas
	--<< START translate >>--
	title = "Negozio del Cappellaio Matto",--turnState.name.."È il tuo turno"
	yes   = "Sì",
	no    = "No",
	gorro = "copricapo",
	lanza = "lancia",
	doyouwant1 = "Vuoi comprare",
	doyouwantH = "questo copricapo?",
	doyouwantS = "questa lancia?",
	--<< END translate >>--
}
return tableText
local tableText = {
	title = "Amici",
	addFriend = "Aggiungi amico",
	addWithGame = "Aggiungi più amici con...",
	pressing = "Aggiungi più amici toccando \"+\"",
	solicitud = "Il seguente utente vuole essere tuo amico",
	notLogged = "Non hai effettuato l'accesso, per invitare amici devi accedere o creare un nuovo account. \nPuoi effettuare queste operazioni nel menu Opzioni."
}
return tableText
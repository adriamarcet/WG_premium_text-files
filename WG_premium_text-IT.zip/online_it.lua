local tableText = {
	title = "Duello online",
	urTurn = "È il tuo turno!",
	newGame = "Crea una nuova partita",
	friendDuel = "Sfida un amico",
	randomDuel = "Avversario casuale",
	waitingForOpponent = "In attesa di un avversario...",
}
return tableText
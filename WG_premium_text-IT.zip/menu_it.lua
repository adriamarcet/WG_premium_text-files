--<< Textos del menu principal >>--
local tableText = {
	--<< START translate >>--
	btnPlay = "Partita Locale",
	btnClasic = "Modalità Classica",
	btnDuel = "Modalità Duello",
	btnOnline = "Partita Online",
	btnShop = "Negozio del Cappellaio Matto",
	btnHowPlay = "Come giocare",
	btnTuto = "Tutorial",
	btnRules = "Regole del gioco",
	btnNewGame = "Nuova partita",
	savedGames = "Partite salvate", 
	smsDelete1 = "Elimina una partita salvata a",
	smsDelete2 = "Creane una nuova",
	smsDeletePop = "Vuoi eliminare la partita?"
	--<< END translate >>--
	--<< START translate >>--
	errorNC1 = "Non sei connesso a internet",
	errorNC2 ="Controlla la tua connessione internet e riprova",
	--<< END translate >>--
}
return tableText
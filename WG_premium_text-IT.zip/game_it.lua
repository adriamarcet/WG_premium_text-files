--<< Textos del ingame >>--
local tableText = {
	--<< START translate >>--
	inicioTurno = "È il tuo turno",--turnState.name.." È il tuo turno"
	descartar   = "Vuoi scartare questa tessera?",
	afterDescarte2peon = "Scegli quale soldato tornerà nel gruppo",
	movimientoIni = "Tocca il sentiero",--..color.." per spostare il soldato"
	movimientoFin = " spostare il soldato",
	["01"]   = "Scegli una torre",
	["02"]  = " e muovila",
	},
	btnSetSalir     ="Salva e esci",
	btnSetContinuar = "Continua a giocare",
	nameSaveGame = "Nome partita salvata"
	gameName = "Partita ",
	clasificacion = "Classifiche",
	winner = "Vincitore!",
	loserDuelo = "Sconfitto",
	waitingPlayer = "In attesa del tuo avversario",
	mensajeConejoMonedas1 = "Hai guadagnato ", --X
	mensajeConejoMonedas2 = "Monete coniglio",
	--<< END translate >>--
	--<< START translate >>--
	error1 = "           deve contenere meno di 15 caratteri",
	error2 = "Errore: Il nome inserito non è corretto,"
	--<< END translate >>--
}
return tableText